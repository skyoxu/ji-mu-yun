# External Semantic Review Application

This package is bound to repository commit
`bd210cef05c16f106a34a0aee6063e1fc9c32675` and the current R3 semantic
handoff. It disposes all 63 deferred obligations individually.

## Semantic result

- 37 obligations are semantically covered by existing FR/NFR/SM and A-* IDs.
- 16 are repository-wide operator policies outside this feature's acceptance universe.
- 8 are structural or explanatory source fragments.
- 1 keeps the existing FR-14/NFR-11 safe floor while deferring any broader partial-reuse policy.
- 1 PRD recommendation is superseded by AD-16, FR-9, FR-13, NFR-7, and SM-2.
- No new FR, NFR, SM, or A-* identifier is required.

The `not_applicable` mapping status means “not an additional standalone
obligation.” It does not discard the underlying rule. Existing canonical
requirements and adjacent Architecture `Binds` rows retain the rule's
normative coverage.

## Apply through VDD repair

1. Publish `vdd-review-run.v1.json` at `docs/vdd-review-run.v1.json`.
2. Keep the predecessor mapping and conformance artifacts immutable.
3. Publish a schema-complete VDD repair input that binds the predecessor source
   freeze, predecessor requirements mapping, this review run, and the 63
   reviewed obligation IDs.
4. Publish a successor source-freeze manifest whose `repair_input` points to
   that repair input and whose `requirements_manifest` points to
   `requirements-acceptance-mapping.v1.reviewed.json`.
5. Run `vdd-conformance-exact-cover` against the successor freeze and reviewed
   mapping. Publish authorization only after the result is `conformant`.

Do not validate the reviewed mapping against the current predecessor
`current-bound-20260826` freeze: that predecessor intentionally has
`repair_input: null`, while approved semantic dispositions require an
explicit repair-bound successor.
