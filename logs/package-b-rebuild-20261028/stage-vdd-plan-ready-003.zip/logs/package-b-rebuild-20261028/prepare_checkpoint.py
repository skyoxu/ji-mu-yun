"""Create a bounded, source-only Package B rebuild checkpoint (not execution proof)."""
from pathlib import Path, PurePosixPath
import subprocess,hashlib,json,zipfile,re,datetime
R=Path('/workspace/ji-mu-yun'); B=R/'logs/package-b-rebuild-20261028'; B.mkdir(exist_ok=True)
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
MAIN=subprocess.check_output(['git','rev-parse','main'],cwd=R,text=True).strip()
packs=['vdd-execution-plan','quick-dev-tdd-adapter','run-phase-bootstrap-review','run-refactor-implementation-acceptance','maintain-knowledge-base']
prefixes=['.agents/skills/'+p+'/' for p in packs]+['scripts/vdd/','scripts/quick_dev/','scripts/toolchain/knowledge_query/']
exact=['AGENTS.md','knowledge/toolchain-workflow-index.md','docs/workflows/skill-control-plane-evolution-requirements.md','scripts/sc/validate_skill_quality.py','scripts/sc/config/skill-authoring-standard.v1.json','scripts/sc/schemas/skill-quality-contract.v1.schema.json','scripts/sc/schemas/skill-quality-result.v1.schema.json','docs/standards/skill-authoring-standard.md','docs/adr/ADR-0062-repository-skill-authoring-contract.md','docs/adr/ADR-0041-bootstrap-review-execution-control-plane-ownership.md','docs/adr/ADR-0048-repository-knowledge-locator-workflow-consumption.md','knowledge/planning-query.toml','scripts/workflow_host.py','scripts/workflow_unit_budget.py','scripts/execution_environment.py','docs/workflows/caller-session-execution.md']
forbidden_parts={'.git','.codex','.aws','__pycache__','.pytest_cache','node_modules','_bmad','_bmad-output','logs'}
secrets=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'gh[pousr]_[A-Za-z0-9]{25,}'),re.compile(rb'AKIA[0-9A-Z]{16}'),re.compile(rb'sk-[A-Za-z0-9]{32,}')]
entries=[]; payload={}; scanner=[]
for label,ref in [('original-head',HEAD),('committed-main-reference',MAIN)]:
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',ref],cwd=R,text=True).splitlines()
 selected=[n for n in names if n in exact or any(n.startswith(p) for p in prefixes)]
 for n in selected:
  p=PurePosixPath(n)
  if any(t in forbidden_parts for t in p.parts) or n.endswith('.user.toml') or p.name.startswith('.env'):continue
  data=subprocess.check_output(['git','show',ref+':'+n],cwd=R)
  if any(q.search(data) for q in secrets):scanner.append(label+'/'+n);continue
  archive_path='sources/'+label+'/'+n
  payload[archive_path]=data
  entries.append({'archive_path':archive_path,'repository_path':n,'ref':ref,'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data),'role':'committed-source-reference'})
if scanner:raise SystemExit('Potential credentials detected in selected source paths: '+json.dumps(scanner))
status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
old='execution-plans/2026-08-18-toolchain-workflow-repair/skill-input/prestart-40-output/skill-input-context.v1.json'
w=(R/old).read_bytes(); h=subprocess.check_output(['git','show','HEAD:'+old],cwd=R)
assert w==h,'Existing unrelated file has real byte changes; preserve before proceeding'
manifest={'schema':'package-b.rebuild-source-checkpoint.v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorizes':[],'workspace':str(R),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip(),'original_head':HEAD,'committed_main_reference':MAIN,'source_only':True,'not_old_candidate_recovery':True,'original_status':status.splitlines(),'unrelated_dirty_marker':{'path':old,'sha256':hashlib.sha256(w).hexdigest(),'bytes_equal_head':True},'deleted_paths':[],'files':entries,'excluded':['device configuration','credentials','BMAD native installation','unrelated logs and historical runtime evidence','old missing Package B implementation and receipts'],'notes':['Two explicitly separated committed source sets. No reconstructed implementation or execution receipt. Original dirty marker has identical bytes to HEAD. Main synchronization has not been executed. No branch switch.']}
payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=B/'package-b-rebuild-source-checkpoint-20261028.zip'
assert not archive.exists(),'Checkpoint archive already exists; do not overwrite'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,d in sorted(payload.items()):z.writestr(n,d)
restore=B/'restore-validation-source-checkpoint';restore.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for i in z.infolist():
  p=PurePosixPath(i.filename);assert not p.is_absolute() and '..' not in p.parts
 z.extractall(restore)
for e in entries:assert hashlib.sha256((restore/e['archive_path']).read_bytes()).hexdigest()==e['sha256']
(B/'SOURCE-CHECKPOINT-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
receipt={'archive':str(archive),'size_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_file_count':len(entries),'restore_validation':'all file hashes matched','restore_directory':str(restore),'credentials_scan':'no configured hard-secret signatures found; explicit source allowlist only','library_saved':False}
(B/'SOURCE-CHECKPOINT-LOCAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
