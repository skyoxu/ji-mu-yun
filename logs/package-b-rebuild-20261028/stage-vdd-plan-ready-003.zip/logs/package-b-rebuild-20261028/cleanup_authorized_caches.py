"""Remove only user-authorized regenerable caches and verified restore copies."""
from pathlib import Path
import os,json,hashlib,shutil,datetime
R=Path('/workspace/ji-mu-yun'); B=R/'logs/package-b-rebuild-20261028'
roots=[('nuget-http-cache',Path('/workspace/.cloud-tools/dotnet-home/.local/share/NuGet/http-cache'),'Public NuGet HTTP cache; recover through the existing configured official feed.'),('nuget-package-cache',Path('/workspace/.cloud-tools/nuget'),'Public NuGet package cache; future dotnet restore must reacquire dependencies. Installed SDK and configuration are excluded.'),('own-verified-restore-copy',B/'restore-validation-source-checkpoint','Restore exact source bytes from the verified ZIP and private Library libfile_c86a7e97d6ec8191b8e678af15faddc6; archive is retained.')]
def fs():
 v=os.statvfs(R);return {'available_bytes':v.f_bavail*v.f_frsize,'free_blocks':v.f_bfree,'available_inodes':v.f_favail}
for label,root,recovery in roots:
 receipt=B/('cleanup-'+label+'.json')
 if receipt.exists():raise SystemExit('Existing cleanup receipt: do not repeat '+label)
 assert root.is_dir() and not root.is_symlink() and root.resolve()==root
 entries=[]
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  if p.is_symlink():assert p.resolve().is_relative_to(root),'External symlink: stop before removal'
  entries.append({'relative_path':str(p.relative_to(root)),'size_bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'is_directory':p.is_dir(),'is_symlink':p.is_symlink()})
 if label=='own-verified-restore-copy':
  m=json.loads((B/'SOURCE-CHECKPOINT-MANIFEST.json').read_text());d=json.loads((B/'SOURCE-CHECKPOINT-DURABLE-RECEIPT.json').read_text());a=Path(d['archive'])
  assert d['library_status']=='succeeded' and hashlib.sha256(a.read_bytes()).hexdigest()==d['sha256']
  assert all(hashlib.sha256((root/e['archive_path']).read_bytes()).hexdigest()==e['sha256'] for e in m['files'])
 before=fs();v={'schema':'package-b.authorized-cache-cleanup.v1','label':label,'root':str(root),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recovery_source':recovery,'before':before,'entries':entries,'status':'prepared'}
 receipt.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
 shutil.rmtree(root)
 after=fs();v.update({'after':after,'actual_available_byte_delta':after['available_bytes']-before['available_bytes'],'status':'removed-authorized-copy','root_absent':not root.exists()})
 receipt.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v[k] for k in ['label','root','before','after','actual_available_byte_delta','status']}),flush=True)
