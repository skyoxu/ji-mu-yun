"""Save selected current task bytes and verify an independent non-Git restore."""
from pathlib import Path
from hashlib import sha256
import datetime,json,zipfile
ROOT=Path(__file__).resolve().parents[2];B=ROOT/'logs/package-b-rebuild-20261028'
name='stage-input-and-vdd-authoring-001'
archive=B/(name+'.zip');restore=B/(name+'-restore-validation')
if archive.exists() or restore.exists():raise SystemExit('Snapshot destination already exists; preserve it')
selected=[ROOT/p for p in ['scripts/toolchain/knowledge_query/adapter.py','scripts/toolchain/knowledge_query/tests/test_reference_materialization.py','docs/adr/ADR-0048-repository-knowledge-locator-workflow-consumption.md','docs/workflows/skill-control-plane-evolution-requirements.md']]
selected+=list((ROOT/'docs/workflows/inputs/package-b-rebuild-20261028').glob('*'))
selected+=list((B/'model-inputs').glob('*.json'))
selected+=[B/p for p in ['CURRENT-CHECKPOINT.json','MAIN-SYNC-RESULT.json','reference-red-after-fixture-fix.log','reference-green.log','reference-native-regression-configured.log','query-related-regression.log','query-related-selected-tests.json','knowledge-publication-native.log','author_v3.py','v3_specs.py','respond_worker.py']]
for p in (B/'vdd-host-session').glob('*/request.json'):
 if (p.parent/'response.json').exists():selected += [p,p.parent/'response.json']
entries=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(selected)):
  if not p.is_file() or p.is_symlink():raise ValueError('Invalid selected file: '+str(p))
  data=p.read_bytes();rel=p.relative_to(ROOT).as_posix();entries.append({'path':rel,'size':len(data),'sha256':sha256(data).hexdigest()});z.writestr(rel,data)
 manifest={'schema':'package-b.stage-snapshot.v1','created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'fb676bc398f653a2ffa869c95d6c8d632f6f9796','scope':'Current source/canonical input, completed author responses and selected original regression/publication logs; NOT a completed VDD plan or old missing candidate recovery.','files':entries,'excluded':['private BMAD/device configuration','credentials','active compiler output and pending requests','unrelated source/evidence','large historical fixtures']}
 z.writestr('SNAPSHOT-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
restore.mkdir()
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None:raise ValueError('CRC failure')
 z.extractall(restore)
 for e in entries:
  data=(restore/e['path']).read_bytes()
  if len(data)!=e['size'] or sha256(data).hexdigest()!=e['sha256']:raise ValueError('Restore mismatch')
receipt={'archive':archive.relative_to(ROOT).as_posix(),'size':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'restored_files_verified':len(entries),'restore_directory':restore.relative_to(ROOT).as_posix(),'durability':'Local verified snapshot only; no new Library upload performed','scope':manifest['scope']}
(B/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
