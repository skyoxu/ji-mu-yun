"""Inspect actual pending worker contracts without duplicated advisory material."""
from pathlib import Path
import json
B=Path(__file__).resolve().parent
for p in (B/'vdd-host-session').glob('*/request.json'):
 if (p.parent/'response.json').exists() or (p.parent/'result.json').exists():continue
 q=json.loads(p.read_text());print('REQUEST',q['request_id'],'OUTPUT',q['output_path'])
 parts=q['prompt'].split('INPUT:\n',1)
 print('\n'.join(l for l in parts[0].splitlines() if l and not l.startswith('{') and not l.startswith('Before factual'))[-4000:])
 if len(parts)!=2:continue
 x=json.loads(parts[1]);print('PAYLOAD_KEYS',list(x));x=x.get('input',x)
 for k,v in x.items():
  if k in ['planning_source_observations','repository_path_context']:continue
  if k=='source_contracts':print('SOURCE_REFS',[e.get('source_ref') for e in v]);continue
  if k=='source_index':print('FROZEN_SOURCES',[(e['source_ref'],e.get('text_sha256')) for e in v.get('entries',[])]);continue
  if k=='obligations':
   for o in v:print(o['obligation_id'],o['subject'],'|',o['expected_behavior'])
   continue
  print(k,json.dumps(v,indent=2))
