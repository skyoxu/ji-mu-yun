"""Local-only, selected task snapshot; never uploads or deletes source/evidence."""
from pathlib import Path
from hashlib import sha256
import datetime,json,zipfile
ROOT=Path(__file__).resolve().parents[2];B=ROOT/'logs/package-b-rebuild-20261028';label='stage-vdd-plan-ready-003'
archive=B/(label+'.zip');restore=B/(label+'-restore-validation')
if archive.exists() or restore.exists():raise SystemExit('Preserve existing stage destination')
files=[]
for ref in ['scripts/toolchain/knowledge_query/adapter.py','scripts/toolchain/knowledge_query/tests/test_reference_materialization.py','scripts/sc/tests/test_skill_quality_package_b.py','docs/workflows/skill-control-plane-evolution-requirements.md','docs/adr/ADR-0048-repository-knowledge-locator-workflow-consumption.md']:
 files.append(ROOT/ref)
for root in [ROOT/'docs/workflows/inputs/package-b-rebuild-20261028',ROOT/'docs/workflows/inputs/package-b-rebuild-20261028-r2',ROOT/'execution-plans/2026-10-28-skill-compliance-package-b-rebuild',ROOT/'execution-plans/2026-10-28-skill-compliance-package-b-rebuild-r2']:
 files.extend(p for p in root.rglob('*') if p.is_file())
# Preserve the exact native first-use JSON and receipt, not feature implementation.
for package in ['vdd-execution-plan','quick-dev-tdd-adapter','run-phase-bootstrap-review','run-refactor-implementation-acceptance','maintain-knowledge-base']:
 files += [ROOT/'.agents/skills'/package/'SKILL.md',ROOT/'.agents/skills'/package/'skill-quality.v1.json',ROOT/'.agents/skills'/package/'references/package-dependencies.v1.json']
for p in B.rglob('*'):
 rel=p.relative_to(B)
 if any(part.endswith('-restore-validation') for part in rel.parts):continue
 if not p.is_file() or p.suffix=='.zip' or p.name.startswith(label):continue
 if p.name in ['vdd-compile-r2.log']:continue
 if 'vdd-host-session' in rel.parts:
  if p.name=='session.json':files.append(p)
  elif (p.parent/'response.json').exists():files.append(p)
  continue
 files.append(p)
entries=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  if p.is_symlink():raise ValueError('Symlink is not snapshot input')
  payload=p.read_bytes();ref=p.relative_to(ROOT).as_posix();entries.append({'path':ref,'bytes':len(payload),'sha256':sha256(payload).hexdigest()});z.writestr(ref,payload)
 manifest={'schema':'package-b.stage-snapshot.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':'fb676bc398f653a2ffa869c95d6c8d632f6f9796','baseline_library_file_id':'libfile_c86a7e97d6ec8191b8e678af15faddc6','stage':'Corrected r2 VDD plan-ready (77 atomic rows,77 acceptances; plan SHA25635f1b074853d6cfa2a169caf5d15551432de2d510c3b96bf419fcc50fd8bc933). First native probe retained and not implementation-complete. Both original and corrected canonical inputs and VDD histories remain available.','scope':'Current source/doc/test overlay, both canonical versions, complete original VDD plan/cache, completed author requests/responses, current first-use interface originals and probe originals.','excluded':['credentials','device/native BMAD configuration and installation','private transmission packaging','old fixture archives','unrelated logs/source','none: no active compiler or business test at snapshot creation'],'files':entries}
 z.writestr('SNAPSHOT-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
restore.mkdir()
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None:raise ValueError('Snapshot CRC failure')
 z.extractall(restore)
 for e in entries:
  payload=(restore/e['path']).read_bytes()
  if len(payload)!=e['bytes'] or sha256(payload).hexdigest()!=e['sha256']:raise ValueError('Restore mismatch: '+e['path'])
manifest_path=B/(label+'-manifest.json');manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'archive':archive.relative_to(ROOT).as_posix(),'archive_bytes':archive.stat().st_size,'archive_sha256':sha256(archive.read_bytes()).hexdigest(),'manifest':manifest_path.relative_to(ROOT).as_posix(),'manifest_sha256':sha256(manifest_path.read_bytes()).hexdigest(),'file_count':len(entries),'uncompressed_bytes':sum(e['bytes'] for e in entries),'crc':'passed','restoration':'All selected file bytes independently restored and verified','restore_directory':restore.relative_to(ROOT).as_posix(),'external_persistence':'NOT uploaded; baseline Library checkpoint does not cover this new snapshot','source_deletion':'None'}
(B/(label+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
