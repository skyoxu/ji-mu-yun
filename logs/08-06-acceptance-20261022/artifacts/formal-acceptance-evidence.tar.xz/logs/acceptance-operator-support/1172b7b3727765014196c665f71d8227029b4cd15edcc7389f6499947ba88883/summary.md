# Acceptance status

Status: failed

Blocker: Failed actions: acceptance-package-a-terminal

Inspect the blocker and incomplete actions below. Repair the named owner input and use its existing recovery entry; do not edit or automatically retry stale evidence.

## Actions

- acceptance-adoption-and-source-binding: completed
- acceptance-package-a-terminal: failed
- acceptance-package-a-public-cli: blocked
- acceptance-acceptance-package-validation: blocked
- acceptance-acceptance-finalization-regressions: blocked
- acceptance-current-q8-read-only: blocked

## Suggested checks

- package-a-terminal: ["/workspace/scratch/e4e648ddd442/acceptance-0806-env/bin/python", "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "scripts/sc/tests/test_skill_quality_core.py", "scripts/sc/tests/test_skill_quality_examples.py", "scripts/sc/tests/test_skill_quality_capabilities.py", "scripts/sc/tests/test_skill_quality_migration.py", "--basetemp", "/workspace/scratch/e4e648ddd442/acceptance-isolated-fixtures/package-a-terminal-r4"] — Registered argv names an affected file.
- package-a-public-cli: ["/workspace/scratch/e4e648ddd442/acceptance-0806-env/bin/python", "-B", "scripts/sc/validate_skill_quality.py", "--repository-root", ".", "--policy", "scripts/sc/config/skill-authoring-standard.v1.json", "--skill-root", "scripts/sc/tests/fixtures/skill-quality/reference-skill", "--mode", "strict"] — Registered argv names an affected file.
- Unregistered suggestion: ["py", "-3", "-m", "pytest", ".agents/skills/run-refactor-implementation-acceptance/tests/test_toolchain_domain.py", "-q"] — Affected Python test; suggestion is not a registered required check.
- Unregistered suggestion: ["py", "-3", "-m", "pytest", ".agents/skills/vdd-execution-plan/scripts/tests/test_ch456_v3_execution_contract.py", "-q"] — Affected Python test; suggestion is not a registered required check.
- Unregistered suggestion: ["py", "-3", "-m", "pytest", ".agents/skills/vdd-execution-plan/scripts/tests/test_ch456_v3_frozen_source_projection.py", "-q"] — Affected Python test; suggestion is not a registered required check.
- Unregistered suggestion: ["py", "-3", "-m", "pytest", ".agents/skills/vdd-execution-plan/scripts/tests/test_ch456_v3_group_safety.py", "-q"] — Affected Python test; suggestion is not a registered required check.
- Unregistered suggestion: ["py", "-3", "-m", "pytest", ".agents/skills/vdd-execution-plan/scripts/tests/test_published_v1_source_bound_split.py", "-q"] — Affected Python test; suggestion is not a registered required check.

## Limits

- One-hop hints only; dynamic imports and runtime wiring may be absent.
- Name-only Python matches are heuristic; inspect their source before adding checks.
- Source inventory truncated to 5000 files.
- Oversize source not scanned: .agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: .agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Source not scanned: .agents/skills/vdd-execution-plan/scripts/tests/test_ch456_v3_inline_context_repair.py
- Oversize source not scanned: .skill-input-work/acceptance-08-05-c15c2839-budget3/54bf3609b2474498ade77afa4f27cac2/prepared.json
- Oversize source not scanned: .skill-input-work/acceptance-08-05-c15c2839-budget3/65b417fc8d06474387047f66cd6238cd/prepared.json
- Oversize source not scanned: .skill-input-work/acceptance-08-05-c15c2839-budget3/d3181296941d498b98d63a970ce639e7/prepared.json
- Oversize source not scanned: PhaseA.Platform.Tests/Browser/BrowserUiRendererTests.cs
- Oversize source not scanned: PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: PhaseA.Platform/Browser/BrowserUiRenderer.cs
- Oversize source not scanned: PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-07-phase-a-frontend-gdd-to-module-workflow-hardening/100-implementation-acceptance-matrix.md
- Oversize source not scanned: execution-plans/2026-07-07-phase-a-frontend-gdd-to-module-workflow-hardening/schemas/godot-ui-style-contract.v1.field-map.json
- Oversize source not scanned: execution-plans/2026-07-07-phase-a-frontend-gdd-to-module-workflow-hardening/schemas/implementation-acceptance-matrix.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r10/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r10/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r10/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r11/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r11/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r11/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r12/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r12/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r12/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r13/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r13/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r13/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r3/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r3/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r3/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r4/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r4/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r4/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r5/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r5/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r5/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r6/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r6/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r6/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r7/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r7/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r7/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r8/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r8/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r8/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r9/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r9/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/.acceptance-snapshots/2026-08-04-rmap-acceptance-r9/execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-15-repository-maintenance-tdd-adapter/schemas/predicate-artifact-closure.v1.json
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair01/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair01/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair01/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair02/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair02/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair02/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair03/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair03/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair03/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair04/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair04/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-07-31-b823ab2-repair04/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p1/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p1/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p1/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p1/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p1/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p2/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p2/.agents/skills/run-phase-bootstrap-review/tests/test_bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p2/PhaseA.Platform.Tests/Runs/PrototypeQuickFixServiceTests.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p2/PhaseA.Platform/Data/PhaseAMetadataStore.cs
- Oversize source not scanned: execution-plans/2026-07-25-four-domain-knowledge-context-engineering-plan/.acceptance-snapshots/2026-08-02-afaed9a-r1p2/PhaseA.Platform/Runs/PrototypeIterationPlanService.cs
- Oversize source not scanned: execution-plans/2026-07-27-refactor-implementation-acceptance-skill/.acceptance-snapshots/2026-07-29-r3/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-27-refactor-implementation-acceptance-skill/.acceptance-snapshots/2026-07-30-r4/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Oversize source not scanned: execution-plans/2026-07-27-refactor-implementation-acceptance-skill/.acceptance-snapshots/2026-07-30-successor-r4/.agents/skills/run-phase-bootstrap-review/scripts/bootstrap_review.py
- Hash-checked baseline Git bytes versus declared candidate commit/snapshot bytes. Truncated to 200000 characters; read the referenced source for the rest.
