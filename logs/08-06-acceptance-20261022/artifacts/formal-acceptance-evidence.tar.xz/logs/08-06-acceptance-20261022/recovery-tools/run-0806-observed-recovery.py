from pathlib import Path
import json,subprocess,sys,hashlib,runpy,contextlib,io,traceback
root=Path('/workspace/scratch/e4e648ddd442/08-06-acceptance-20261022');target='execution-plans/2026-08-06-skill-authoring-standard';d=root/target/'acceptance-inputs/acceptance-08-06-20261022-r4';b=root/'logs/08-06-acceptance-20261022';script='.agents/skills/run-refactor-implementation-acceptance/scripts/acceptance_cli.py';prior=json.loads((d/'coordinator-result.v3.json').read_text());binding=prior['runBinding'];run_id='acceptance-08-06-20261022-observed-recovery';run=root/target/'acceptance-runs'/run_id
common=['--run-input-hash',binding['runInputHash'],'--contract-hash',binding['contractHash'],'--knowledge-context-hash',binding['knowledgeContextHash']]
def call(args,label):
 out,err=io.StringIO(),io.StringIO();observed=[];code=0
 def trace(frame,event,arg):
  name=frame.f_code.co_name
  if name not in {'_validate_read_only_status_delta','_repository_content_manifest'}:return None
  if event=='exception' and name=='_validate_read_only_status_delta':
   before=frame.f_locals['before'];after=frame.f_locals['after'];observed.append({'guard':name,'changed':[{'path':k,'before':before.get(k),'after':after.get(k)}for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)]})
  elif event=='exception' and name=='_repository_content_manifest':observed.append({'guard':name,'reason':str(arg[1]),'relative':frame.f_locals.get('relative')})
  return trace
 sys.argv=[str(root/script),*args]
 sys.path.insert(0,str((root/script).parent))
 with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
  sys.settrace(trace)
  try:runpy.run_path(str(root/script),run_name='__main__')
  except SystemExit as e:code=e.code or 0
  except BaseException:code=1;traceback.print_exc()
  finally:sys.settrace(None)
 prefix='observed-'+label
 (b/(prefix+'.stdout.json')).write_text(out.getvalue());(b/(prefix+'.stderr.txt')).write_text(err.getvalue());(b/(prefix+'.observation.json')).write_text(json.dumps({'exit_code':code,'observed':observed,'authorizes':[]},indent=2)+'\n')
 if code:print(label,err.getvalue()[-2000:],json.dumps(observed),flush=True);raise SystemExit(code)
 return json.loads(out.getvalue())

entry=call(['start-or-resume','--repository-root',str(root), '--target-plan',target,'--run-id',run_id,*common,'--skill-input-receipt',str(d/'skill-input-v2/acceptance/current.v1.json'),'--skill-input-contract',str(d/'skill-input-contract.v1.json')],'recovery-absolute-root-start');print('Native recovery run created',entry['runId'],flush=True)
link=run/'recovery-link.v1.json'
if not link.exists():link.write_text(json.dumps({'schema':'acceptance-explicit-recovery-link.v1','predecessorRunId':'acceptance-08-06-20261022-environment-recovery','predecessorResult':{'path':(d/'coordinator-result.v3.json').relative_to(root).as_posix(),'sha256':'sha256:'+hashlib.sha256((d/'coordinator-result.v3.json').read_bytes()).hexdigest()},'reason':'Preserve failed environment-recovery. The same registered package validation subsequently passed native controlled-command read-only validation independently. Run an explicit same-input recovery through the public native CLI with in-process exception-only observation for every manifest guard. No test, predicate or gate is replaced.','inputs':binding,'authorizes':[]},indent=2)+'\n')
prepared=run/'prepare-run.v1.json'
if not prepared.exists():prepared.write_bytes((d/'prepared-run-input.v1.json').read_bytes())
assert prepared.read_bytes()==(d/'prepared-run-input.v1.json').read_bytes()
for i in range(6):
 v=call(['resume-persisted-run','--repository-root',str(root), '--run-dir',str(run),'--actions',str(d/'action-dag.v1.json'),'--command-registry',str(d/'command-registry.v1.json'),*common],f'recovery-action-{i+1}')
 print(i+1,v.get('actionId'),v.get('receipt',{}).get('exitCode'),flush=True)
 if v.get('receipt',{}).get('exitCode')!=0:raise SystemExit(1)
v=call(['finalize-deterministic-run','--repository-root',str(root), '--run-dir',str(run),'--run-input',str(prepared),'--actions',str(d/'action-dag.v1.json'),'--command-registry',str(d/'command-registry.v1.json'),'--out',str(run/'formal-finalization.v1.json')],'recovery-finalization')
print('FINAL',json.dumps(v,sort_keys=True),flush=True)
