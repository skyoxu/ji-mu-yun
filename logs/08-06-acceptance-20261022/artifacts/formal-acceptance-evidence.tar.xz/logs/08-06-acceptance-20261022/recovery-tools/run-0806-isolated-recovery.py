from pathlib import Path
import json,subprocess,sys,hashlib
root=Path('/dev/shm/08-06-acceptance-isolated');target='execution-plans/2026-08-06-skill-authoring-standard';d=root/target/'acceptance-inputs/acceptance-08-06-20261022-r4';b=root/'logs/08-06-acceptance-20261022';script='.agents/skills/run-refactor-implementation-acceptance/scripts/acceptance_cli.py';prior=json.loads((d/'coordinator-result.v3.json').read_text());binding=prior['runBinding'];run_id='acceptance-08-06-20261022-isolated-recovery';run=root/target/'acceptance-runs'/run_id
common=['--run-input-hash',binding['runInputHash'],'--contract-hash',binding['contractHash'],'--knowledge-context-hash',binding['knowledgeContextHash']]
def call(args,label):
 p=subprocess.run([sys.executable,'-B',script,*args],cwd=root,capture_output=True,text=True);(b/(label+'.stdout.json')).write_text(p.stdout);(b/(label+'.stderr.txt')).write_text(p.stderr)
 if p.returncode:print(label,p.stdout[-1500:],p.stderr[-3000:],flush=True);raise SystemExit(p.returncode)
 return json.loads(p.stdout)
entry=call(['start-or-resume','--repository-root',str(root), '--target-plan',target,'--run-id',run_id,*common,'--skill-input-receipt',str(d/'skill-input-v2/acceptance/current.v1.json'),'--skill-input-contract',str(d/'skill-input-contract.v1.json')],'isolated-recovery-start');print('Native recovery run created',entry['runId'],flush=True)
link=run/'recovery-link.v1.json'
if not link.exists():link.write_text(json.dumps({'schema':'acceptance-explicit-recovery-link.v1','predecessorRunId':'acceptance-08-06-20261022-observed-recovery','predecessorResult':{'path':(d/'coordinator-result.v3.json').relative_to(root).as_posix(),'sha256':'sha256:'+hashlib.sha256((d/'coordinator-result.v3.json').read_bytes()).hexdigest()},'reason':'Prior observed run failed when a released prior-action claim reappeared during a controlled subprocess. This explicit successor uses an isolated tmpfs worktree with identical inputs and unchanged read-only validation. Preserve all predecessor runs.','inputs':binding,'authorizes':[]},indent=2)+'\n')
prepared=run/'prepare-run.v1.json'
if not prepared.exists():prepared.write_bytes((d/'prepared-run-input.v1.json').read_bytes())
assert prepared.read_bytes()==(d/'prepared-run-input.v1.json').read_bytes()
for i in range(6):
 v=call(['resume-persisted-run','--repository-root',str(root), '--run-dir',str(run),'--actions',str(d/'action-dag.v1.json'),'--command-registry',str(d/'command-registry.v1.json'),*common],f'isolated-recovery-action-{i+1}')
 print(i+1,v.get('actionId'),v.get('receipt',{}).get('exitCode'),flush=True)
 if v.get('receipt',{}).get('exitCode')!=0:raise SystemExit(1)
v=call(['finalize-deterministic-run','--repository-root',str(root), '--run-dir',str(run),'--run-input',str(prepared),'--actions',str(d/'action-dag.v1.json'),'--command-registry',str(d/'command-registry.v1.json'),'--out',str(run/'formal-finalization.v1.json')],'isolated-recovery-finalization')
print('FINAL',json.dumps(v,sort_keys=True),flush=True)
