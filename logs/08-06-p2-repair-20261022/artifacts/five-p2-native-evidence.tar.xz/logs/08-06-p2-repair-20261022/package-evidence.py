"""Package immutable native outputs without rewriting their bytes."""
from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path.cwd();log=Path('logs/08-06-p2-repair-20261022');target=Path('execution-plans/2026-08-06-skill-authoring-standard');art=log/'artifacts';art.mkdir(exist_ok=True)
inputs=[target/'acceptance-inputs'/n for n in ('acceptance-08-06-p2-20261022','acceptance-08-06-p2-20261022-tmpfs','acceptance-08-06-p2-20261022-prerequisites')]
runs=[target/'acceptance-runs'/n for n in ('acceptance-cb9fd8c39325169d','acceptance-08-06-p2-20261022-git-recovery','acceptance-08-06-p2-20261022-fixture-recovery','acceptance-2677f519e0491a3c')]
roots=[log,*inputs,*runs,*[target/'.acceptance-snapshots'/n for n in ('acceptance-08-06-p2-20261022','acceptance-08-06-p2-20261022-tmpfs')],*[Path('.skill-input-work')/n for n in ('acceptance-08-06-p2-20261022','acceptance-08-06-p2-20261022-tmpfs')],*[Path('logs/acceptance-operator-support')/n for n in ('7224c07ead0bf13fcd235447a23fe94612d8c70e12babd046a24db00e4d6f55a','a8964e2a03903a6c3666c9be46d67061eb873d5025369d1299677f774789a3ff')]]
files=set()
for folder in roots:
 if folder.exists():files.update(p for p in folder.rglob('*') if p.is_file() and not p.is_symlink() and art not in p.parents and p.name!='publication-files.json')
files.update(target.glob('acceptance-run-request.acceptance-08-06-p2-20261022*.v1.json'))
files.add(target/'knowledge-context.refactor-acceptance-p2-20261022.v1.json')
files.add(target/'acceptance-current.v1.json')
files=sorted(files,key=str);archive=art/'five-p2-native-evidence.tar.xz';rows=[]
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in files:
  raw=p.read_bytes();rows.append({'path':str(p),'bytes':len(raw),'sha256':'sha256:'+hashlib.sha256(raw).hexdigest()})
  info=tar.gettarinfo(str(p),arcname=str(p));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as f:tar.addfile(info,f)
# Verify the archive against the complete recorded file manifest before publishing.
with tarfile.open(archive,'r:xz') as tar:
 for member,row in zip(tar.getmembers(),rows,strict=True):
  assert member.name==row['path'] and member.isfile()
  assert 'sha256:'+hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
manifest={'schema':'08-06-five-p2-evidence-archive.v1','authorizes':[],'repair_baseline':'b9eba90549beaf0f470fa68562144f4d68e27c18','product_commit':'7b3bb1ce83637c718c2b9fc71d565409fb17fead','acceptance_candidate':'11590e6616f86cd8f2d3bea5dcd2a6316df4c2e2','archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':'sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest()},'file_count':len(rows),'files':rows}
mp=art/'evidence-manifest.v1.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
final=target/'acceptance-runs/acceptance-2677f519e0491a3c';out=target/'acceptance-inputs/acceptance-08-06-p2-20261022-tmpfs'
direct=[archive,mp,target/'acceptance-current.v1.json',out/'FINAL-REPORT.md',out/'coordinator-request.v3.json',out/'coordinator-result.v3.json',final/'finalization/acceptance-passed.v1.json',final/'finalization/acceptance-result-final.v1.json',final/'actions/acceptance-current-q8-read-only/attempt-001/result.json',log/'closure-r2/implementation-complete.json',log/'closure-r2/acceptance-current-quick-dev-binding.json']
publication=[]
for p in direct:publication.append({'path':str(p),'bytes':p.stat().st_size,'git_blob':subprocess.check_output(['git','hash-object',str(p)],text=True).strip()})
(log/'publication-files.json').write_text(json.dumps(publication,indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'file_count':len(rows),'manifest_bytes':mp.stat().st_size,'publication_bytes':sum(x['bytes'] for x in publication),'publish_file_count':len(publication)}))
