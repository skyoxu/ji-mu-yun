"""Explicit inputs only; native owners publish Q8, Skill input and Acceptance."""
from pathlib import Path
import json, hashlib, subprocess, sys
ROOT=Path.cwd(); LOG=Path('logs/08-06-p2-repair-20261022'); TARGET=Path('execution-plans/2026-08-06-skill-authoring-standard'); RUN='acceptance-08-06-p2-20261022'; OUT=TARGET/'acceptance-inputs'/RUN
SCRIPT='.agents/skills/run-refactor-implementation-acceptance/scripts/'
sys.path.insert(0,str(ROOT))
def read(p): return json.loads(Path(p).read_text())
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  assert read(p)==d, 'Existing input differs: '+str(p)
  return
 with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
def ref(p):return {'path':str(p),'sha256':'sha256:'+hashlib.sha256(Path(p).read_bytes()).hexdigest()}
def call(args,label):
 p=subprocess.run([sys.executable,'-B',*args],capture_output=True,text=True,cwd=ROOT)
 (LOG/(label+'.stdout.json')).write_text(p.stdout);(LOG/(label+'.stderr.txt')).write_text(p.stderr)
 if p.returncode:print(label,p.stdout[-3000:],p.stderr[-3000:],flush=True);raise SystemExit(p.returncode)
 return json.loads(p.stdout)
session=read(LOG/'session-request-r3.json');receipt=Path(session['out']);semantic=TARGET/'package-a-completion-plan/semantic-plan-bundle.v1.json'
binding={'semanticPlan':ref(semantic),'receipt':ref(receipt),'snapshotRoots':session['snapshot_roots'],'sourceCommit':session['source_commit'],'baseCommit':session['base_commit']}
write(LOG/'closure-r2/acceptance-current-quick-dev-binding.json',binding)
request=read('logs/08-06-acceptance-20261022/projection-request-r4.v1.json')
request.update(runId=RUN,changeId='08-06-package-a-five-p2-successor',candidateRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),currentQuickDev=binding,implementationReceiptPath=str(receipt),implementationReceiptHash=ref(receipt)['sha256'],knowledgeContextPath='knowledge-context.refactor-acceptance-p2-20261022.v1.json')
for c in request['commands']:
 c['executable']='/workspace/scratch/e4e648ddd442/p2-acceptance-env/bin/python'
 c['argv']=[x.replace('acceptance-08-06-20261022-prerequisites','acceptance-08-06-p2-20261022-prerequisites').replace('logs/08-06-acceptance-20261022/quick-dev/closure-r3/acceptance-current-quick-dev-binding.json',str(LOG/'closure-r2/acceptance-current-quick-dev-binding.json')).replace('/workspace/scratch/e4e648ddd442/acceptance-isolated-fixtures/','/workspace/scratch/e4e648ddd442/p2-acceptance-fixtures/') for x in c['argv']]
write(LOG/'projection-request-r3.json',request)
projection=call([SCRIPT+'compact_vdd_projection.py','--repository-root',str(ROOT),'--request',str(LOG/'projection-request-r3.json')],'projection')
print('projection',projection,flush=True)
call([SCRIPT+'acceptance_cli.py','prepare-run','--input',str(TARGET/f'acceptance-run-request.{RUN}.v1.json'),'--knowledge-context',request['knowledgeContextPath'],'--prerequisite-bundle',f'acceptance-inputs/{RUN}/compact-vdd-acceptance-prerequisite-bundle.v1.json','--out',str(OUT/'prepared-run-input.v1.json')],'prepare')
contract=Path('.agents/skills/run-refactor-implementation-acceptance/references/skill-input-contract.v1.json')
(OUT/'skill-input-contract.v1.json').write_bytes(contract.read_bytes())
old=read(LOG/'skill-input-request-template.json')
old.update(plan_id=RUN,storage=str(OUT/'skill-input-v2/acceptance'))
for role,paths in old['inputs'].items():old['inputs'][role]=[p.replace('acceptance-08-06-20261022-prerequisites','acceptance-08-06-p2-20261022-prerequisites') for p in paths]
for row in old['sources']:
 row['path']=row['path'].replace('acceptance-08-06-20261022-prerequisites','acceptance-08-06-p2-20261022-prerequisites');row['sha256']=ref(row['path'])['sha256']
from scripts.python.skill_input_selection import selection_identity
freeze={'schema_version':'skill-input-direct-source-freeze.v2','sourceSelectionHash':selection_identity(old['sources'],consumer=old['consumer'],policy_revision=old['policy_revision'])['sourceSelectionHash'],'authorizes':[]}
write(OUT/'skill-input-freeze.v2.json',freeze)
old['bindings']={'contract':ref(OUT/'skill-input-contract.v1.json'),'registry':ref(OUT/'command-registry.v1.json'),'authority':ref(TARGET/'acceptance-inputs/acceptance-08-06-p2-20261022-prerequisites/skill-input-authority.v1.json'),'knowledge_freeze':ref(OUT/'skill-input-freeze.v2.json')}
write(OUT/'skill-input-request.v2.json',old)
print('Successor inputs created; consume through live skill-input v2 next.',flush=True)
