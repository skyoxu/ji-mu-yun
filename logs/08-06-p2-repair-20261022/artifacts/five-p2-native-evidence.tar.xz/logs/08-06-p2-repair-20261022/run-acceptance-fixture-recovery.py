"""Explicit environment recovery through existing Acceptance-owned entries."""
from pathlib import Path
import json,subprocess,sys,hashlib
root=Path.cwd();target=Path('execution-plans/2026-08-06-skill-authoring-standard');inputs=target/'acceptance-inputs/acceptance-08-06-p2-20261022';log=Path('logs/08-06-p2-repair-20261022');script='.agents/skills/run-refactor-implementation-acceptance/scripts/acceptance_cli.py'
prior=json.loads((inputs/'coordinator-result.v3.json').read_text());binding=prior['runBinding'];run_id='acceptance-08-06-p2-20261022-fixture-recovery';run=target/'acceptance-runs'/run_id
common=['--run-input-hash',binding['runInputHash'],'--contract-hash',binding['contractHash'],'--knowledge-context-hash',binding['knowledgeContextHash']]
def call(args,label):
 p=subprocess.run([sys.executable,'-B',script,*args],cwd=root,capture_output=True,text=True)
 for suffix,value in [('stdout.json',p.stdout),('stderr.txt',p.stderr)]:
  with (log/(label+'.'+suffix)).open('x') as f:f.write(value)
 if p.returncode:print(label,p.stdout[-2000:],p.stderr[-2000:],flush=True);raise SystemExit(p.returncode)
 return json.loads(p.stdout)
entry=call(['start-or-resume','--repository-root',str(root),'--target-plan',str(target),'--run-id',run_id,*common,'--skill-input-receipt',str(inputs/'skill-input-v2/acceptance/current.v1.json'),'--skill-input-contract',str(inputs/'skill-input-contract.v1.json')],'fixture-recovery-start');print('started',entry['runId'],flush=True)
link={'schema':'acceptance-explicit-recovery-link.v1','predecessorRunId':'acceptance-08-06-p2-20261022-git-recovery','predecessorResult':{'path':str(log/'recovery-action-5.stdout.json'),'sha256':'sha256:'+hashlib.sha256((log/'recovery-action-5.stdout.json').read_bytes()).hexdigest()},'reason':'The previous run passed actions 1-4. Action 5 failed because pytest fixture repositories were on device 27 while inherited TMPDIR was on device 26, causing EXDEV during atomic projection publication. Both fixture roots and execution TMPDIR now use device 27. Preparation alone used device 26 to match the actual candidate checkout. Rerun the same six registered actions in a new native run; preserve both predecessors. No source, contract, registry or expectations changed.','inputs':binding,'authorizes':[]}
with (run/'recovery-link.v1.json').open('x') as f:json.dump(link,f,indent=2);f.write('\n')
prepared=run/'prepare-run.v1.json'
with prepared.open('xb') as f:f.write((inputs/'prepared-run-input.v1.json').read_bytes())
for i in range(6):
 v=call(['resume-persisted-run','--repository-root',str(root),'--run-dir',str(run),'--actions',str(inputs/'action-dag.v1.json'),'--command-registry',str(inputs/'command-registry.v1.json'),*common],f'fixture-recovery-action-{i+1}')
 print(i+1,v.get('actionId'),v.get('receipt',{}).get('exitCode'),flush=True)
 if v.get('receipt',{}).get('exitCode')!=0:raise SystemExit(1)
v=call(['finalize-deterministic-run','--repository-root',str(root),'--run-dir',str(run),'--run-input',str(prepared),'--actions',str(inputs/'action-dag.v1.json'),'--command-registry',str(inputs/'command-registry.v1.json'),'--out',str(run/'formal-finalization.v1.json')],'fixture-recovery-finalization')
print('FINAL',json.dumps(v,sort_keys=True),flush=True)
