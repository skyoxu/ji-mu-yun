# Windows replay repair: unresolved orchestration deadlines

Authority: Accepted ADR-0058 (Toolchain Skill Replay Portability and Evaluation
Seeds). C3 remains OPEN. No VDD, Quick Dev or Acceptance workflow was started.
All derived records are non-authorizing; no historical evidence was rebound.

The candidate removes Git clone from fresh file-tree reconstruction, using the
same read-only gitdir pattern as native Matrix replay. The new process still
executes all Probes and Consumer transitions and compares snapshot, inspected
identity, verdict and coverage. A regression verifies unchanged original HEAD
and index. Real core.autocrlf=true configuration is tested.

Profiling also found duplicate file opens in dependency closure: Python bytes
were read for import analysis, then read again for hashing. Each invocation now
hashes the same bytes it analyzes. The next invocation reads current bytes and
membership again; closure, trust, manifest and execution results are not cached.
The new test failed on two reads before implementation and passed afterwards.

## Preserved native runs

- `../windows-fresh-replay-local-20261008T154416`: successful real fresh replay,
  98 native starts/exits and no clone commands. This predates the closure repair
  and is not rebound to later candidate bytes. The profiling file is diagnostic,
  not a budget-eligible execution receipt.
- `../observable-verification-20261008T074912Z-3ec508b1`: 42 unittest passed;
  338 pytest passed, 2 failed, 0 skipped; all 340 nodes finished with native
  JUnit and source_stable=true. Both failures correspond to fresh-child 60-second
  timeouts, surfaced as failed positive-control assertions.
- `../observable-verification-20261008T092604Z-f011cbf7`: 43 unittest passed;
  both previous failing selectors passed with native JUnit and source_stable=true.
  This is targeted evidence, not a substitute for full current scope.
- `../observable-verification-20261008T093416Z-a559141a`: 43 unittest passed;
  31 of 340 pytest nodes finished, 2 unsuccessful reports, source_stable=true.
  Fresh-child again exhausted 60 seconds; native Matrix exhausted its 60-second
  aggregate budget while launching a scenario with only 0.3945 seconds left.
  This run was explicitly stopped after recurrence. See operator-stop.json.
  Missing final pytest JUnit is not repaired or replaced with synthetic JUnit.

## Unresolved decision

The previous micro-optimizations do not prove stable Windows completion.
Review the separation between full replay orchestration and individual native
validator deadlines, and measure Matrix reconstruction/preparation versus its
actual native execution budget. Do not blindly increase all deadlines, exclude
consumers, cache execution/trust results, or combine old passes into a current
340/340 claim. Any deadline contract change needs an explicit maintainer
decision and an ADR update before implementation.

No implementation-complete or Acceptance pass is established. Changes are
still local; no new candidate commit or remote SHA is claimed by this report.
