"""Diagnostic only: measure a full Matrix with 60s leaf and 180s total bounds.

Accepted ADR-0058; this measurement cannot establish validation or Acceptance.
No production source, historical receipt or trust authority is modified.
"""
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from scripts.sc import skill_package_replay as replay

runtime = replay.runtime
OUTPUT = Path(__file__).parent / "measurement"
OUTPUT.mkdir(exist_ok=False)
trace = OUTPUT / "native-processes"
trace.mkdir()
os.environ["TC_D1_NATIVE_TRACE_DIR"] = str(trace)


def source():
    return {"head": runtime.git(ROOT, "rev-parse", "HEAD").decode().strip(),
            "files": runtime.bindings(ROOT, runtime.SOURCE_ROOTS)}


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


before = source()
save("source-before.json", before)
original_execute = runtime.execute
original_timeout = runtime.TIMEOUT_SECONDS
calls = []


def execute(command, root, timeout=original_timeout, output_limit=runtime.OUTPUT_LIMIT):
    started = time.monotonic()
    row = {"command": command, "requested_seconds": timeout, "leaf_limit_seconds": min(60, timeout)}
    try:
        result = original_execute(command, root, min(60, timeout), output_limit)
        row.update(exit_code=result.returncode, pid=result.pid)
        return result
    finally:
        row["elapsed_seconds"] = time.monotonic() - started
        calls.append(row)
        print(json.dumps(row), flush=True)


started = time.monotonic()
result = {"diagnostic_only": True, "authorizes": []}
try:
    matrix = runtime.prepare_matrix(ROOT, replay.PRIMARY_TARGET, replay.PRIMARY_CAPABILITY,
                                    runtime.TRUST_BASELINE, (OUTPUT / "matrix.json").relative_to(ROOT).as_posix())
    result["preparation_seconds"] = time.monotonic() - started
    execution_started = time.monotonic()
    # Only this diagnostic interpreter permits the wider total. Every launched
    # native command is still capped at 60s, including descendant validators.
    with patch.object(runtime, "TIMEOUT_SECONDS", 180), patch.object(runtime, "execute", execute):
        observation, code = runtime.replay_matrix(ROOT, matrix)
    result.update(matrix_elapsed_seconds=time.monotonic() - execution_started,
                  measured_exit_code=code, measured_observation=observation)
except Exception as exc:
    result.update(diagnostic=str(exc))
finally:
    after = source()
    save("source-after.json", after)
    result.update(source_stable=before == after, total_seconds=time.monotonic() - started,
                  native_calls=calls, native_call_seconds=sum(row["elapsed_seconds"] for row in calls),
                  diagnostic_only=True, authorizes=[])
    save("result.json", result)
    print(json.dumps({k: v for k, v in result.items() if k not in {"measured_observation", "native_calls"}}), flush=True)
