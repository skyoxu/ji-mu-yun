# Windows replay budget separation

Authority: Accepted ADR-0058, 2026-10-08 budget separation amendment.
Base HEAD: `00d773a8`. Implementation changes are local and uncommitted.
C3 remains OPEN; all derived records are non-authorizing (`authorizes: []`).
No VDD, Quick Dev, Acceptance, trust-source replacement or historical receipt
rebinding was performed.

## Measurements and decision

`measurement/result.json` is explicitly diagnostic-only. All six Matrix cases
and both Stable/Candidate subjects executed: Matrix replay took 43.95s, input
generation 4.39s, top-level native commands 36.38s. Diagnostic total allowed
180s, but every native command retained its 60s limit. Source binding stayed
stable. This is not a formal pass under the old 60s aggregate policy.

Earlier Windows evidence preserved beside this directory exhausted the 60s
fresh-child and Matrix deadlines. A prior diagnostic fresh profile took about
72s. Single-leaf behavior does not justify raising the Consumer/Validator
ceiling: current validation recorded 473 observed native leaf invocations,
with a maximum completed observer duration of about 0.635s.

The new independent ceilings are:

- Consumer/Validator: 60s, unchanged.
- Full fresh-child replay orchestration: 120s, including its nested execution,
  dependency and snapshot work; parent reconstruction is covered by the CER
  parent's existing 180s deadline.
- Matrix aggregate replay: 120s, including fixture/trust checks, Stable
  materialization, all wrapper/scenario executions and final identity checks.
  Input generation precedes replay and is measured separately. Every launched
  command has the smaller of 60s and actual remaining aggregate time.
- Matrix CER transport: 150s, leaving reporting/cleanup margin, not extra
  aggregate execution time. General transport stays capped at 180s; direct
  per-node supervision stays at 300s.

Stricter declared Matrix bounds remain binding; a declaration cannot expand
the ceiling. Timeout, exit 124 and output exhaustion remain unsuccessful.
No execution result, trust verdict, closure, or snapshot is reused as a pass.

## Current verification

- `red/`: seven regression nodes failed against the missing separate deadline
  owner and incorrect fresh-child budget. Native JUnit and raw outputs remain.
- `green/`: the same seven nodes passed after budget separation. This precedes
  one additional real-work timing regression and is not rebound to it.
- `validation/`: current Windows run, 50/50 unittest and 28/28 pytest passed;
  zero skips, real JUnit, complete phase events, `source_stable=true`.
  Selectors are in `validation-scope.json` and the collected manifest is in
  `validation/selected-nodeids.json`.
- Three actual fresh-child executions in the current pytest run completed in
  48.08s, 48.85s and 49.20s, each with the explicit 120s orchestration budget.
  Original reconstructed identity, semantic verdict, coverage and snapshot
  comparisons passed without substituting previous outputs.

This is targeted Windows validation, not a current 340/340 full-scope claim,
implementation-complete, Q8 or Acceptance approval. Full-scope verification
remains the next release-verification step; do not combine historical passes
with these results into an invented full-scope result.

`git diff --check` passed. No commit, push, remote SHA or clean-worktree claim
is made. Historical failed/interrupted evidence remains unchanged.
