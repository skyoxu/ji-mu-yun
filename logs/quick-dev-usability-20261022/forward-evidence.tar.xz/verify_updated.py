from drive import *
import time,signal
name='updated-present'
invoke(name,'preflight','preflight-session','--execution-request','session.json')
assert not (base/name/'logs').exists()
for i in range(1,5):
 r=invoke(name,f'advance-{i}','advance-session','--execution-request','session.json','--max-steps','1')
assert r['status']=='implementation-complete'
before={str(p.relative_to(base/name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/name/'logs').rglob('*') if p.is_file()}
r=invoke(name,'reuse','advance-session','--execution-request','session.json','--max-steps','1');assert r['status']=='implementation-complete'
after={str(p.relative_to(base/name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/name/'logs').rglob('*') if p.is_file()}
(base/(name+'-immutability.json')).write_text(json.dumps({'before':before,'after':after,'identical':before==after},indent=2));assert before==after
name='updated-interrupted';root=base/name
invoke(name,'materialize','advance-session','--execution-request','session.json','--max-steps','1')
cmd=[sys.executable,'-B','scripts/quick_dev/run.py','--plan','plan','--action','advance-session','--execution-request','session.json','--max-steps','1']
p=subprocess.Popen(cmd,cwd=root,env=E,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
marker=root/'logs/probe-entered.marker';start=time.monotonic()
while not marker.exists() and p.poll() is None and time.monotonic()-start<15:time.sleep(.05)
entered=marker.exists();os.killpg(p.pid,signal.SIGTERM);stdout,stderr=p.communicate()
(base/(name+'-kill.json')).write_text(json.dumps({'command':cmd,'cwd':str(root),'returncode':p.returncode,'probe_call_entered':entered,'stdout':stdout,'stderr':stderr},indent=2));assert entered
before={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'logs').rglob('*') if f.is_file()}
for label in ['resume','resume-again']:
 r=invoke(name,label,'advance-session','--execution-request','session.json','--max-steps','1');assert r['status']=='blocked'
 assert json.loads((base/(name+'-'+label+'.json')).read_text())['exit']==1
after={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'logs').rglob('*') if f.is_file()}
(base/(name+'-immutability.json')).write_text(json.dumps({'before':before,'after':after,'identical':before==after},indent=2));assert before==after
