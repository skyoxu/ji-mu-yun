"""Fresh fixture construction; captures actual source/copy bytes, never old evidence."""
import os,sys,json,shutil,subprocess,hashlib,datetime
from pathlib import Path
os.environ['PYTHONDONTWRITEBYTECODE']='1'
repo=Path('/workspace/scratch/e4e648ddd442/quick-dev-usability-20261022')
sys.path.insert(0,str(repo/'.agents/skills/quick-dev-tdd-adapter/tools/tests'))
from test_execution_session import setup_session
import pytest
base=Path(__file__).parent
scopes=['scripts','.agents/skills/quick-dev-tdd-adapter','.agents/skills/vdd-execution-plan']
def sha(path):return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(root):
 return {p.relative_to(root).as_posix():sha(p) for rel in scopes for p in sorted((root/rel).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
for name,present in [('present',(True,True)),('partial',(True,False)),('interrupted',(True,True))]:
 root=base/name;root.mkdir()
 before=inventory(repo)
 for rel in scopes:shutil.copytree(repo/rel,root/rel,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 copied=inventory(root); after=inventory(repo)
 manifest={'schema':'forward-copy-hashes.v1','captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(repo),'fixture_root':str(root),'scopes':scopes,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),'source_before':before,'copy':copied,'source_after':after,'all_equal':before==copied==after}
 (base/(name+'-source-copy-hashes.json')).write_text(json.dumps(manifest,indent=2))
 assert manifest['all_equal'],'source changed during copy or copy differs'
 with pytest.MonkeyPatch.context() as m: semantic,request=setup_session(root,m,present)
 if name=='partial':
  test=root/'tests/test_one.py'
  test.write_text(test.read_text().replace("def test_value_2():\n actual=value(2)\n if actual!=2: print('FAILURE_ID:FAIL-2')\n assert actual==2", "@pytest.mark.parametrize('kind', [1,2])\ndef test_value_2(kind):\n actual=value(kind)\n if actual!=kind: print('FAILURE_ID:FAIL-2')\n assert actual==kind"))
 if name=='interrupted':
  test=root/'tests/test_one.py'
  test.write_text(test.read_text().replace('def test_value_1():\n','def test_value_1():\n from pathlib import Path\n import time\n Path("logs/probe-entered.marker").write_text("test call entered")\n time.sleep(10)\n'))
 if name!='present':
  subprocess.run(['git','add','tests/test_one.py'],cwd=root,check=True)
  subprocess.run(['git','-c','user.name=Test','-c','user.email=test@example.invalid','commit','-qm',name+' fixture cases'],cwd=root,check=True)
  request['source_commit']=request['base_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 (root/'session.json').write_text(json.dumps(request,indent=2)); (root/'roots.json').write_text(json.dumps(request['snapshot_roots'],indent=2))
 print(name,'copied files',len(copied),'equal',manifest['all_equal'],'fixture commit',request['source_commit'])
