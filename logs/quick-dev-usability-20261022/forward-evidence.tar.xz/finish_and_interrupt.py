from drive import *
import time,signal
r=json.loads((base/'partial-refactor.stdout.json').read_text());assert r['status']=='refactor-observed',r
(base/'partial-refactor-invocation.json').write_text(json.dumps({'command':[sys.executable,'-B','scripts/workflow_host.py','--session','logs/refactor-caller','--host-timeout-seconds','300','quick-dev','--','--plan','plan','--slice','S1','--run-dir','logs/session/S1','--action','run-refactor','--profile','standard','--worker-timeout-seconds','20'],'cwd':str(base/'partial'),'exit':0,'stdout_file':'partial-refactor.stdout.json','stderr_file':'partial-refactor.stderr.txt'},indent=2))
for i in range(5,8):
 r=invoke('partial',f'advance-{i}','advance-session','--execution-request','session.json','--max-steps','1')
 if r.get('status')!='paused':break
assert r['status']=='implementation-complete',r
for name in ['present','partial']:
 logs=base/name/'logs'
 before={str(p.relative_to(base/name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in logs.rglob('*') if p.is_file()}
 r=invoke(name,'reuse-verified','advance-session','--execution-request','session.json','--max-steps','1')
 after={str(p.relative_to(base/name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in logs.rglob('*') if p.is_file()}
 check={'before':before,'after':after,'identical':before==after,'status':r.get('status')}
 (base/(name+'-immutability.json')).write_text(json.dumps(check,indent=2));assert check['identical']
 print(name,'all log files immutable',len(after))
name='interrupted';root=base/name
invoke(name,'materialize','advance-session','--execution-request','session.json','--max-steps','1')
cmd=[sys.executable,'-B','scripts/quick_dev/run.py','--plan','plan','--action','advance-session','--execution-request','session.json','--max-steps','1']
p=subprocess.Popen(cmd,cwd=root,env=E,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
marker=root/'logs/probe-entered.marker';start=time.monotonic()
while not marker.exists() and p.poll() is None and time.monotonic()-start<15:time.sleep(.05)
entered=marker.exists()
os.killpg(p.pid,signal.SIGTERM);stdout,stderr=p.communicate()
(base/'interrupted-kill.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'returncode':p.returncode,'probe_call_entered':entered,'stdout':stdout,'stderr':stderr},indent=2));assert entered
before={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'logs').rglob('*') if f.is_file()}
for label in ['resume','resume-again']:
 r=invoke(name,label,'advance-session','--execution-request','session.json','--max-steps','1');assert r['status']=='blocked'
after={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'logs').rglob('*') if f.is_file()}
(base/'interrupted-immutability.json').write_text(json.dumps({'before':before,'after':after,'identical':before==after},indent=2));assert before==after
print('interrupted actual case entered, repeated blocked resumes immutable')
