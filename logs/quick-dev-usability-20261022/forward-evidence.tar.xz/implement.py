from drive import *
root=base/'partial'; req=json.loads((root/'session.json').read_text())
common=['--slice','S1','--run-dir','logs/session/S1','--snapshot-roots','roots.json','--source-commit',req['source_commit'],'--base-commit',req['base_commit']]
r=invoke('partial','handoff','implementation-handoff',*common,'--out','logs/session/handoff.json')
if r.get('status')!='implementation-worker-required':raise SystemExit(1)
(root/'candidate.py').write_text('def value(kind):\n return {1: 1, 2: 2}[kind]\n')
r=invoke('partial','finish','implementation-finish',*common,'--before-state','logs/session/handoff.json','--changed-path','candidate.py','--out','logs/session/finish.json')
if r.get('status')!='implementation-successor':raise SystemExit(1)
invoke('partial','advance-4','advance-session','--execution-request','session.json','--max-steps','1')
