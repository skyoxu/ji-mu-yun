def value(kind):
 return {1: 1, 2: 2}[kind]
