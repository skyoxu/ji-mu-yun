from pathlib import Path
import pytest
@pytest.mark.cer_assertion('AS-1', 'AS-2')
def test_terminal():
 root=Path(__file__).resolve().parents[1]
 assert (root/'candidate.txt').read_text(encoding='utf-8').strip()=='green'
