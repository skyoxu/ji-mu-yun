import pytest
from candidate import value
@pytest.mark.cer_assertion('AS-1')
def test_value_1():
 from pathlib import Path
 import time
 Path("logs/probe-entered.marker").write_text("test call entered")
 time.sleep(10)
 actual=value(1)
 if actual!=1: print('FAILURE_ID:FAIL-1')
 assert actual==1
@pytest.mark.cer_assertion('AS-2')
def test_value_2():
 actual=value(2)
 if actual!=2: print('FAILURE_ID:FAIL-2')
 assert actual==2
