import pytest
from candidate import value
@pytest.mark.cer_assertion('AS-1')
def test_value_1():
 actual=value(1)
 if actual!=1: print('FAILURE_ID:FAIL-1')
 assert actual==1
@pytest.mark.cer_assertion('AS-2')
@pytest.mark.parametrize('kind', [1,2])
def test_value_2(kind):
 actual=value(kind)
 if actual!=kind: print('FAILURE_ID:FAIL-2')
 assert actual==kind
