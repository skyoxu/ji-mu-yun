import os,sys,json,subprocess,hashlib
from pathlib import Path
base=Path(__file__).parent
E={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/workspace/scratch/e4e648ddd442/online-route-test-deps'}
def invoke(name,label,action,*args):
 root=base/name; out=base/(name+'-'+label+'.json')
 cmd=[sys.executable,'-B','scripts/quick_dev/run.py','--plan','plan','--action',action,*args]
 p=subprocess.run(cmd,cwd=root,env=E,text=True,capture_output=True)
 data={'command':cmd,'cwd':str(root),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 out.write_text(json.dumps(data,indent=2))
 try: result=json.loads(p.stdout)
 except: print(name,label,'NOT JSON',p.stdout[-1000:],p.stderr[-1000:]);return {}
 print(name,label,'exit',p.returncode,'status',result.get('status'),'next',result.get('required_next_action'),'reason',result.get('reason'),'steps',result.get('steps'))
 return result
if __name__=='__main__':
 for name in ['present','partial']:
  invoke(name,'preflight','preflight-session','--execution-request','session.json')
  print(name,'logs exists after preflight',(base/name/'logs').exists())
  invoke(name,'selection','inspect-selection','--slice','S1')
  for i in range(1,5):
   r=invoke(name,f'advance-{i}','advance-session','--execution-request','session.json','--max-steps','1')
   if r.get('status')!='paused':break
  if name=='present':
   before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/name/'logs').rglob('process-receipt.v2.json')}
   invoke(name,'reuse','advance-session','--execution-request','session.json','--max-steps','1')
   after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/name/'logs').rglob('process-receipt.v2.json')}
   print('present unchanged receipts',before==after,len(after))
